import { Link } from 'react-router-dom';
import { Flower2, Phone, Mail, Instagram, Twitter, Linkedin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="h-[60px] bg-slate-950/90 border-t border-white/10 flex items-center justify-center gap-10 text-[12px] text-slate-400">
      <div>Blossom Developers &copy; {new Date().getFullYear()}</div>
      <div className="hidden sm:block">Designed by Naveed Butt</div>
      <div className="hidden md:block">03204703662</div>
      <div className="hidden lg:block">blossomwebsitedevolper@gmail.com</div>
    </footer>
  );
}
