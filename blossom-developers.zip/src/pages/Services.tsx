import { Link } from 'react-router-dom';
import { Check, ArrowRight, Globe, ShoppingCart, User, Layout as LayoutIcon, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

const services = [
  {
    title: 'Business Website',
    desc: 'Custom-built professional websites for established businesses and startups.',
    icon: Globe,
    features: ['Responsive Design', 'SEO Optimization', 'Contact Forms', 'CMS Integration']
  },
  {
    title: 'Ecommerce Website',
    desc: 'Fully functional online stores with secure payment gateways and product management.',
    icon: ShoppingCart,
    features: ['Product Catalog', 'Shopping Cart', 'Payment Gateway', 'Order Tracking']
  },
  {
    title: 'Portfolio Website',
    desc: 'Showcase your work and skills with a stunning, personalized portfolio site.',
    icon: User,
    features: ['Gallery Sections', 'Skill Highlights', 'Resume Download', 'Social Links']
  },
  {
    title: 'Landing Page',
    desc: 'High-converting single-page websites designed for specific marketing campaigns.',
    icon: LayoutIcon,
    features: ['Lead Generation', 'A/B Testing Ready', 'Fast Loading', 'Call to Actions']
  },
  {
    title: 'Website Redesign',
    desc: 'Give your existing website a modern look and better performance.',
    icon: RefreshCw,
    features: ['UI/UX Update', 'Performance Boost', 'Mobile Optimization', 'Content Refresh']
  }
];

const pricing = [
  {
    name: 'Basic',
    price: 'Starting from $299',
    desc: 'Perfect for small personal projects or simple landing pages.',
    features: ['1-3 Pages', 'Responsive Design', 'Basic SEO', 'Contact Form', '1 Month Support'],
    popular: false
  },
  {
    name: 'Standard',
    price: 'Starting from $599',
    desc: 'Ideal for growing businesses needing a professional presence.',
    features: ['5-8 Pages', 'Advanced SEO', 'CMS Integration', 'Social Media Setup', '3 Months Support'],
    popular: true
  },
  {
    name: 'Premium',
    price: 'Starting from $999',
    desc: 'Comprehensive solutions for ecommerce or complex web apps.',
    features: ['Unlimited Pages', 'Ecommerce Ready', 'Custom Features', 'Premium Support', '1 Year Support'],
    popular: false
  }
];

export default function Services() {
  return (
    <div className="pb-32">
      {/* Header */}
      <section className="pt-20 pb-24 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-display font-bold mb-6"
          >
            Our <span className="text-gradient">Services</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-zinc-400 max-w-2xl mx-auto text-lg"
          >
            We offer a wide range of web development services to help your business thrive in the digital world.
          </motion.p>
        </div>
      </section>

      {/* Service Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-32">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-5">
          {services.map((service, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-5 bg-slate-900/40 border border-white/10 rounded-xl hover:border-sky-400 transition-all group text-center"
            >
              <h3 className="text-lg font-bold mb-2 text-sky-400">{service.title}</h3>
              <p className="text-slate-400 text-[13px] mb-6 leading-relaxed">{service.desc}</p>
              <Link
                to="/contact"
                className="w-full py-2 bg-white/5 hover:bg-white/10 text-white text-[11px] font-semibold rounded-lg border border-white/10 transition-all flex items-center justify-center gap-2"
              >
                Order Now
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Pricing Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Pricing Plans</h2>
          <p className="text-slate-400">Choose the plan that fits your needs.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-4xl mx-auto">
          {pricing.map((plan, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className={`p-8 rounded-xl border ${
                plan.popular 
                ? 'bg-slate-900 border-sky-400 relative shadow-2xl shadow-sky-400/10' 
                : 'bg-white/5 border-white/10'
              } text-center`}
            >
              <h4 className="text-[12px] font-bold text-slate-400 uppercase tracking-widest mb-4">{plan.name}</h4>
              <div className="text-white font-bold text-3xl mb-2">{plan.price.split('from ')[1]}</div>
              <p className="text-slate-400 text-[11px] mb-8 leading-relaxed">{plan.desc}</p>
              <Link
                to="/contact"
                className={`w-full py-3 rounded-lg font-bold transition-all flex items-center justify-center gap-2 ${
                  plan.popular 
                  ? 'bg-sky-500 text-slate-950' 
                  : 'bg-white/5 text-white border border-white/10'
                }`}
              >
                Get Started
              </Link>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
