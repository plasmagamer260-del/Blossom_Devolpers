import { Link } from 'react-router-dom';
import { ExternalLink, Eye } from 'lucide-react';
import { motion } from 'motion/react';

const projects = [
  {
    title: 'Business Website',
    category: 'Corporate',
    image: 'https://picsum.photos/seed/business/800/600',
    desc: 'A modern corporate website for a leading consulting firm.'
  },
  {
    title: 'Ecommerce Store',
    category: 'Retail',
    image: 'https://picsum.photos/seed/shop/800/600',
    desc: 'Full-featured online store with payment integration.'
  },
  {
    title: 'Portfolio Site',
    category: 'Personal',
    image: 'https://picsum.photos/seed/portfolio/800/600',
    desc: 'A creative portfolio for a professional photographer.'
  },
  {
    title: 'Agency Website',
    category: 'Creative',
    image: 'https://picsum.photos/seed/agency/800/600',
    desc: 'Dynamic website for a digital marketing agency.'
  },
  {
    title: 'Restaurant Website',
    category: 'Food',
    image: 'https://picsum.photos/seed/food/800/600',
    desc: 'Elegant website with online reservation system.'
  },
  {
    title: 'Landing Page',
    category: 'Marketing',
    image: 'https://picsum.photos/seed/landing/800/600',
    desc: 'High-converting landing page for a SaaS product.'
  }
];

export default function Portfolio() {
  return (
    <div className="pb-32">
      {/* Header */}
      <section className="pt-20 pb-24 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-display font-bold mb-6"
          >
            Our <span className="text-gradient">Portfolio</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-zinc-400 max-w-2xl mx-auto text-lg"
          >
            Take a look at some of our recent projects and see how we've helped our clients succeed.
          </motion.p>
        </div>
      </section>

      {/* Project Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {projects.map((project, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative bg-slate-900/40 rounded-xl overflow-hidden border border-white/10 hover:border-sky-400 transition-all flex flex-col justify-end p-8 min-h-[240px]"
            >
              {/* Image Stub Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent z-10" />
              <img
                src={project.image}
                alt={project.title}
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:scale-105 transition-transform duration-500"
              />

              {/* Content */}
              <div className="relative z-20">
                <h3 className="text-lg font-bold mb-1">{project.title}</h3>
                <Link
                  to="/contact"
                  className="text-sky-400 text-[12px] font-semibold flex items-center gap-1 hover:gap-2 transition-all"
                >
                  View Project &rarr;
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-32">
        <div className="p-12 md:p-20 bg-zinc-900 border border-zinc-800 rounded-[3rem] text-center">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6">Have a project in mind?</h2>
          <p className="text-zinc-400 mb-10 max-w-xl mx-auto">
            Let's discuss your ideas and turn them into a reality. Our team is ready to help you build your dream website.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 px-8 py-4 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-full transition-all hover:scale-105 active:scale-95"
          >
            Start a Project
          </Link>
        </div>
      </section>
    </div>
  );
}
